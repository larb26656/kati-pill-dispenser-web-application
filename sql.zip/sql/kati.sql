-- phpMyAdmin SQL Dump
-- version 4.6.5.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Nov 15, 2017 at 06:06 PM
-- Server version: 10.1.21-MariaDB
-- PHP Version: 5.6.30

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kati`
--

-- --------------------------------------------------------

--
-- Table structure for table `behavior`
--

CREATE TABLE `behavior` (
  `Behavior_id` int(11) NOT NULL,
  `Behavior_type` enum('tookpill','forgottakepill') COLLATE utf8mb4_unicode_ci NOT NULL,
  `Behavior_datetime` datetime NOT NULL,
  `Schedule_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `behavior`
--

INSERT INTO `behavior` (`Behavior_id`, `Behavior_type`, `Behavior_datetime`, `Schedule_id`) VALUES
(1, '', '2017-08-31 01:00:00', 1),
(7, '', '2017-06-30 00:00:00', 1),
(8, '', '2017-06-30 00:00:00', 6),
(9, '', '2017-06-30 00:00:00', 6),
(10, 'forgottakepill', '2017-11-09 13:00:00', 6),
(11, 'tookpill', '2017-11-03 00:00:00', 11);

-- --------------------------------------------------------

--
-- Table structure for table `behavior_notification`
--

CREATE TABLE `behavior_notification` (
  `Behavior_notification_id` int(11) NOT NULL,
  `Behavior_id` int(11) NOT NULL,
  `Member_id` int(11) NOT NULL,
  `Msg_status` int(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `behavior_notification`
--

INSERT INTO `behavior_notification` (`Behavior_notification_id`, `Behavior_id`, `Member_id`, `Msg_status`) VALUES
(1, 1, 1, 0),
(2, 7, 1, 0);

-- --------------------------------------------------------

--
-- Table structure for table `conversation`
--

CREATE TABLE `conversation` (
  `Conversation_id` int(11) NOT NULL,
  `Conversation_quiz` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Conversation_type` enum('date','time','pill_dispenser') COLLATE utf8mb4_unicode_ci NOT NULL,
  `Conversation_language` enum('thai','english') COLLATE utf8mb4_unicode_ci NOT NULL,
  `Pill_id` int(11) NOT NULL,
  `Conversation_visiblestatus` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `conversation`
--

INSERT INTO `conversation` (`Conversation_id`, `Conversation_quiz`, `Conversation_type`, `Conversation_language`, `Pill_id`, `Conversation_visiblestatus`) VALUES
(1, 'สวัสดี', '', 'thai', 0, 1),
(2, 'กี่โมงแล้ว', '', '', 0, 1),
(3, 'เวลาเท่าไร', '', '', 0, 1),
(4, 'test', 'time', 'thai', 0, 1),
(5, 'test', 'date', 'english', 0, 1),
(6, 'ทดสอบแก้ไข', 'pill_dispenser', 'thai', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `dispenser`
--

CREATE TABLE `dispenser` (
  `Dispenser_id` int(11) NOT NULL,
  `Schedule_id` int(11) NOT NULL,
  `Slot_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `dispenser`
--

INSERT INTO `dispenser` (`Dispenser_id`, `Schedule_id`, `Slot_id`) VALUES
(35, 9, 10),
(36, 0, 12),
(37, 0, 12),
(39, 10, 0),
(40, 10, 10),
(41, 10, 12),
(42, 10, 10),
(43, 10, 12),
(46, 11, 0),
(47, 11, 13),
(48, 12, 10);

-- --------------------------------------------------------

--
-- Table structure for table `member`
--

CREATE TABLE `member` (
  `Member_id` int(11) NOT NULL,
  `Member_firstname` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Member_surname` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `username` varchar(12) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(12) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Member_email` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Admin_permission` tinyint(1) NOT NULL,
  `Member_visiblestatus` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `member`
--

INSERT INTO `member` (`Member_id`, `Member_firstname`, `Member_surname`, `username`, `password`, `Member_email`, `Admin_permission`, `Member_visiblestatus`) VALUES
(1, 'ต่อลาภs', 'ไทยเขียว', 'larb26656', '123456789', 'larb26656@gmail.com', 1, 1),
(2, 'ทดสอบ', 'dasd', 'asdasasdasda', 'asd', 'pic/member/307.jpg', 0, 0),
(3, 'สมศรี', 'นารี', 'test1234', '123456789', 'pic/member/lonely-cat-iari-putra.jpg', 0, 0),
(4, 'สมชาย', 'มาครับ', 'zazaza01', '563214789', 'pic/member/error-advice-triangle-with-exclamation-mark_318-27587.jpg', 0, 1),
(5, 'สมชุบ', 'ทองเปรม', 'somchop1', '123456789', 'pic/member/784931-topic-ix-6.jpg', 0, 1),
(6, 'ทอดสอบ', 'หหห', 'test2222', '123456789', 'aaa@sdasdas.com', 0, 1),
(7, 'asdasd', 'asdasd', 'sssssssss', '1234', 'asdsd@gmail.com', 0, 1),
(8, 'asdasdasd', 'asdasd', 'aaaaaaaaaaaa', '1234', 'asdasd@sasd.com', 0, 1),
(9, 'asdasdasd', 'asdasdas', 'aaaaaaaaaaaa', '1234', 'asdasd@sasd.com', 0, 1),
(10, 'asdasd', 'asdasdas', '12345678', '1234', 'asdasd@sasd.com', 0, 1),
(11, 'asdasd', 'asdasdas', 'asdxczxczxc', '1234', 'asdasd@sasd.com', 0, 1),
(12, 'หฟกฟหก', 'ฟหกฟหก', 'asdasdsss', '1234', 'asdasd@sasd.com', 0, 1),
(13, 'สมชาย', 'เรียนดี', 'somchai01', '1234', 'asdasd@sasd.com', 0, 1),
(14, 'ssss', 'sss', 'asdasdasda', '123456789', 'adsasd@hotm.com', 0, 1),
(15, '', '', '', '', '', 0, 1),
(16, 'test', 'test', 'asdbxzxcz', '123456789', 'asdasd@sasd.com', 0, 1);

-- --------------------------------------------------------

--
-- Table structure for table `memo`
--

CREATE TABLE `memo` (
  `Memo_id` int(11) NOT NULL,
  `Memo_desc` longtext COLLATE utf8mb4_unicode_ci NOT NULL,
  `Memo_notification_date` date NOT NULL,
  `Memo_notification_time` time NOT NULL,
  `Memo_notification_day` varchar(7) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Memo_visiblestatus` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `memo`
--

INSERT INTO `memo` (`Memo_id`, `Memo_desc`, `Memo_notification_date`, `Memo_notification_time`, `Memo_notification_day`, `Memo_visiblestatus`) VALUES
(1, 'เที่ยงแล้วอย่าลืมกินข้าว', '2017-07-29', '08:20:00', '', 0),
(2, 'มีประชุมนัดหมายตอน 5 โมง เย็น', '2017-09-07', '23:53:00', '', 0),
(3, 'เที่ยงแล้วอย่าลืมกินข้าว', '0000-00-00', '05:27:00', '0100000', 0),
(4, 'หมอนัดตรวจสุขภาพ', '0000-00-00', '11:33:00', '0110110', 0),
(5, 'ทดสอบแก้ไข', '0000-00-00', '06:35:00', '1110001', 0),
(11, 'jhkl', '2017-09-14', '21:28:00', '', 0),
(12, 'ssss', '2017-09-14', '21:28:00', '', 1),
(13, 'ทดสอบ', '2017-10-31', '02:36:00', '', 1),
(14, 'aa', '2017-11-05', '05:10:00', '', 1),
(15, 'ทดสอบแก้ไข', '2017-11-06', '22:55:00', '', 0);

-- --------------------------------------------------------

--
-- Table structure for table `memo_log`
--

CREATE TABLE `memo_log` (
  `Memo_log_id` int(11) NOT NULL,
  `Memo_id` int(11) NOT NULL,
  `Memo_log_datetime` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `outsider`
--

CREATE TABLE `outsider` (
  `Outsider_id` int(11) NOT NULL,
  `Outsider_firstname` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Outsider_surname` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Outsider_level` enum('caregiver','doctor') COLLATE utf8mb4_unicode_ci NOT NULL,
  `Outsider_token` varchar(500) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Outsider_visiblestatus` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `outsider`
--

INSERT INTO `outsider` (`Outsider_id`, `Outsider_firstname`, `Outsider_surname`, `Outsider_level`, `Outsider_token`, `Outsider_visiblestatus`) VALUES
(1, 'นายต่อลาภs', 'ไทยเขียว', 'caregiver', 'dTKDp_ehhbw:APA91bGpUSvPk72vFHZAzcbKBGw4jWBoDFLfcwY5_6rIKyZg_G8ISOeVirFeVCnVZS7wYCunvSIJxuL3CCyGDOhI6ylylqN3PQhlhFC5amyX8Bf8Gyu1XDz2oeldcOxv8jRQuM-_1t_j', 1),
(12, '', 'ไทยเขียว2', '', 'eDMWVXGQkaI:APA91bG6hY4DKkJiCUuW-hNLpEZFFjNcQV8-tjVCpOkHvW4io8NoaJq6QBxeviBTthsEgaQWpj7YVXz3wQeoQXVtMYLwdoG-shbETwIPcOSsSVSoBObQy4oNOBkEfH8m23XB7UICfLCq', 1),
(13, 'สมชุบ', 'ทองเปรม', '', '123456', 0),
(14, 'สมชาย', 'อดนอน', '', 'ekXM7QxWsmU:APA91bEcsHvE9sI83gnCF8OwwkEphkl79WDGeYzA-TCQar9PrvDTTO0avJP89VIDrnWF-xgUVuhtYtMLniy5cY0SaEB_mLbhFmmJviEP6LWQCbAik30BQ8gyvqNuqgG_Fd6Co3qCmOfc', 1),
(15, 'test', 'tttt', 'doctor', '111', 0);

-- --------------------------------------------------------

--
-- Table structure for table `pill`
--

CREATE TABLE `pill` (
  `Pill_id` int(11) NOT NULL,
  `Pill_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Pill_commonname` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Pill_brandname` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Pill_properties` varchar(200) COLLATE utf8mb4_unicode_ci NOT NULL,
  `Pill_duration` enum('painorfever','beforebreakfast','beforelunch','beforedinner') COLLATE utf8mb4_unicode_ci NOT NULL,
  `Pill_dispenseramount` int(1) NOT NULL,
  `Pill_left` int(2) NOT NULL,
  `Pill_expiry_date` date NOT NULL,
  `Pill_visiblestatus` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci ROW_FORMAT=COMPACT;

--
-- Dumping data for table `pill`
--

INSERT INTO `pill` (`Pill_id`, `Pill_name`, `Pill_commonname`, `Pill_brandname`, `Pill_properties`, `Pill_duration`, `Pill_dispenseramount`, `Pill_left`, `Pill_expiry_date`, `Pill_visiblestatus`) VALUES
(1, 'พาราเซตามอล 500 มก.', 'พาราเซตามอล 500 มก.', 'BURAPHA', 'ยาบรรเทาปวดลดไข้', 'painorfever', 2, 15, '2020-06-04', 1),
(2, 'ทดสอบ', 'ยาแก้ปวดหัว', 'ฟกหกฟ', 'แก้ปวดหัว', 'beforebreakfast', 1, 8, '2017-08-19', 1),
(3, 'หฟกฟ', 'ฟหก', 'ฟหก ', 'ฟหก', 'beforelunch', 10, 15, '2017-08-18', 1),
(4, 'ยาแก้หวัด', 'test', 'test ', 'แก้หวัด', 'beforedinner', 3, 20, '2017-08-24', 1),
(5, 'sad', 'assad', 'asd ', 'asd', 'painorfever', 2, 4, '2017-09-15', 1),
(6, 'ยาสีดำ', 'หหห', 'หห ', 'หห', 'beforedinner', 3, 15, '2017-09-12', 1),
(7, 'asd', 'asd', 'asd ', 'asd', 'painorfever', 2, 2, '2017-11-10', 1);

-- --------------------------------------------------------

--
-- Table structure for table `pill_log`
--

CREATE TABLE `pill_log` (
  `Pill_log_id` int(11) NOT NULL,
  `Pill_log_type` enum('almostoutofstock','outofstock') COLLATE utf8mb4_unicode_ci NOT NULL,
  `Pill_log_datetime` datetime NOT NULL,
  `Pill_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pill_log`
--

INSERT INTO `pill_log` (`Pill_log_id`, `Pill_log_type`, `Pill_log_datetime`, `Pill_id`) VALUES
(1, '', '2017-06-30 00:00:00', 1),
(2, '', '2017-08-25 02:34:50', 2),
(3, '', '2017-08-25 02:34:57', 2),
(4, '', '2017-08-25 02:38:03', 2),
(5, '', '2017-08-25 02:38:36', 2),
(6, '', '2017-08-25 02:40:50', 2),
(7, '', '2017-08-25 02:41:23', 2),
(8, '', '2017-08-25 02:42:05', 2),
(9, '', '2017-08-25 02:44:04', 2),
(10, '', '2017-08-25 02:45:20', 2),
(11, '', '2017-08-25 02:46:32', 2),
(12, '', '2017-08-25 02:46:44', 2),
(13, '', '2017-08-25 02:47:02', 2),
(14, '', '2017-08-25 02:51:55', 2),
(15, '', '2017-08-25 02:52:11', 2),
(16, '', '2017-08-25 02:52:24', 2),
(17, '', '2017-08-25 02:52:35', 2),
(18, '', '2017-08-25 02:52:39', 2),
(19, '', '2017-08-25 02:55:13', 2),
(20, '', '2017-08-25 03:02:57', 2),
(21, '', '2017-08-25 03:03:08', 2),
(22, '', '2017-08-25 03:03:10', 2),
(23, '', '2017-08-25 03:03:18', 2),
(24, 'outofstock', '2017-11-06 03:03:23', 2),
(25, 'almostoutofstock', '2017-11-06 03:39:08', 2),
(26, '', '2017-08-25 03:39:11', 2);

-- --------------------------------------------------------

--
-- Table structure for table `pill_log_notification`
--

CREATE TABLE `pill_log_notification` (
  `Pill_log_notification_id` int(11) NOT NULL,
  `Pill_log_id` int(11) NOT NULL,
  `Member_id` int(11) NOT NULL,
  `Msg_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `pill_log_notification`
--

INSERT INTO `pill_log_notification` (`Pill_log_notification_id`, `Pill_log_id`, `Member_id`, `Msg_status`) VALUES
(23, 19, 1, 0),
(24, 19, 3, 1),
(25, 19, 4, 1),
(26, 19, 5, 0),
(27, 20, 1, 0),
(28, 20, 3, 1),
(29, 20, 4, 1),
(30, 20, 5, 0),
(31, 21, 1, 0),
(32, 21, 3, 1),
(33, 21, 4, 1),
(34, 21, 5, 0),
(35, 22, 1, 0),
(36, 22, 3, 1),
(37, 22, 4, 1),
(38, 22, 5, 0),
(39, 23, 1, 0),
(40, 23, 3, 1),
(41, 23, 4, 1),
(42, 23, 5, 0),
(43, 24, 1, 0),
(44, 24, 3, 1),
(45, 24, 4, 1),
(46, 24, 5, 0),
(47, 25, 1, 0),
(48, 25, 3, 1),
(49, 25, 4, 1),
(50, 25, 5, 0),
(51, 26, 1, 0),
(52, 26, 3, 1),
(53, 26, 4, 1),
(54, 26, 5, 0);

-- --------------------------------------------------------

--
-- Table structure for table `robot_setting`
--

CREATE TABLE `robot_setting` (
  `Robot_setting_id` int(11) NOT NULL,
  `Robot_lang` enum('thai','english') COLLATE utf8mb4_unicode_ci NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `robot_setting`
--

INSERT INTO `robot_setting` (`Robot_setting_id`, `Robot_lang`) VALUES
(1, 'english');

-- --------------------------------------------------------

--
-- Table structure for table `schedule`
--

CREATE TABLE `schedule` (
  `Schedule_id` int(11) NOT NULL,
  `Schedule_time` time NOT NULL,
  `Schedule_visiblestatus` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `schedule`
--

INSERT INTO `schedule` (`Schedule_id`, `Schedule_time`, `Schedule_visiblestatus`) VALUES
(6, '23:44:00', 0),
(7, '14:17:00', 1),
(8, '10:44:00', 1),
(9, '11:31:00', 0),
(10, '22:21:00', 0),
(11, '22:59:00', 0),
(12, '23:00:00', 0);

-- --------------------------------------------------------

--
-- Table structure for table `slot`
--

CREATE TABLE `slot` (
  `Slot_id` int(11) NOT NULL,
  `Slot_num` int(1) NOT NULL,
  `Pill_id` int(11) NOT NULL,
  `Slot_visiblestatus` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

--
-- Dumping data for table `slot`
--

INSERT INTO `slot` (`Slot_id`, `Slot_num`, `Pill_id`, `Slot_visiblestatus`) VALUES
(1, 0, 5, 0),
(2, 0, 3, 0),
(3, 0, 0, 0),
(4, 0, 2, 0),
(5, 0, 1, 0),
(6, 0, 0, 0),
(7, 0, 0, 0),
(8, 0, 0, 0),
(9, 1, 1, 0),
(10, 1, 6, 1),
(11, 2, 5, 0),
(12, 2, 5, 1),
(13, 3, 1, 1),
(14, 4, 2, 0),
(15, 4, 2, 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `behavior`
--
ALTER TABLE `behavior`
  ADD PRIMARY KEY (`Behavior_id`);

--
-- Indexes for table `behavior_notification`
--
ALTER TABLE `behavior_notification`
  ADD PRIMARY KEY (`Behavior_notification_id`);

--
-- Indexes for table `conversation`
--
ALTER TABLE `conversation`
  ADD PRIMARY KEY (`Conversation_id`);

--
-- Indexes for table `dispenser`
--
ALTER TABLE `dispenser`
  ADD PRIMARY KEY (`Dispenser_id`);

--
-- Indexes for table `member`
--
ALTER TABLE `member`
  ADD PRIMARY KEY (`Member_id`);

--
-- Indexes for table `memo`
--
ALTER TABLE `memo`
  ADD PRIMARY KEY (`Memo_id`);

--
-- Indexes for table `memo_log`
--
ALTER TABLE `memo_log`
  ADD PRIMARY KEY (`Memo_log_id`);

--
-- Indexes for table `outsider`
--
ALTER TABLE `outsider`
  ADD PRIMARY KEY (`Outsider_id`);

--
-- Indexes for table `pill`
--
ALTER TABLE `pill`
  ADD PRIMARY KEY (`Pill_id`);

--
-- Indexes for table `pill_log`
--
ALTER TABLE `pill_log`
  ADD PRIMARY KEY (`Pill_log_id`);

--
-- Indexes for table `pill_log_notification`
--
ALTER TABLE `pill_log_notification`
  ADD PRIMARY KEY (`Pill_log_notification_id`);

--
-- Indexes for table `robot_setting`
--
ALTER TABLE `robot_setting`
  ADD PRIMARY KEY (`Robot_setting_id`);

--
-- Indexes for table `schedule`
--
ALTER TABLE `schedule`
  ADD PRIMARY KEY (`Schedule_id`);

--
-- Indexes for table `slot`
--
ALTER TABLE `slot`
  ADD PRIMARY KEY (`Slot_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `behavior`
--
ALTER TABLE `behavior`
  MODIFY `Behavior_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=12;
--
-- AUTO_INCREMENT for table `behavior_notification`
--
ALTER TABLE `behavior_notification`
  MODIFY `Behavior_notification_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `conversation`
--
ALTER TABLE `conversation`
  MODIFY `Conversation_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
--
-- AUTO_INCREMENT for table `dispenser`
--
ALTER TABLE `dispenser`
  MODIFY `Dispenser_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;
--
-- AUTO_INCREMENT for table `member`
--
ALTER TABLE `member`
  MODIFY `Member_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `memo`
--
ALTER TABLE `memo`
  MODIFY `Memo_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `memo_log`
--
ALTER TABLE `memo_log`
  MODIFY `Memo_log_id` int(11) NOT NULL AUTO_INCREMENT;
--
-- AUTO_INCREMENT for table `outsider`
--
ALTER TABLE `outsider`
  MODIFY `Outsider_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
--
-- AUTO_INCREMENT for table `pill`
--
ALTER TABLE `pill`
  MODIFY `Pill_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=8;
--
-- AUTO_INCREMENT for table `pill_log`
--
ALTER TABLE `pill_log`
  MODIFY `Pill_log_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=27;
--
-- AUTO_INCREMENT for table `pill_log_notification`
--
ALTER TABLE `pill_log_notification`
  MODIFY `Pill_log_notification_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=55;
--
-- AUTO_INCREMENT for table `schedule`
--
ALTER TABLE `schedule`
  MODIFY `Schedule_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;
--
-- AUTO_INCREMENT for table `slot`
--
ALTER TABLE `slot`
  MODIFY `Slot_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=16;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
